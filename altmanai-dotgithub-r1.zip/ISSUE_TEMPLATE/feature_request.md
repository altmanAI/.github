---
name: Feature request
about: Suggest an idea
---

**Problem**
**Proposed solution**
**Canonical references (artifacts/receipts)**
**Risks**
