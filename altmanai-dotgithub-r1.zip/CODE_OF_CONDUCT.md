# Code of Conduct

We commit to a respectful, inclusive community. No harassment, discrimination, doxxing, or hate speech.
Report incidents to **security@altmanai.tech** with subject **[CoC]**.
Violations may result in warnings, issue/PR limits, or bans at maintainers' discretion.
