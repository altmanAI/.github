# Security Policy

- Report vulnerabilities privately to **security@altmanai.tech** with steps to reproduce.
- Please allow 90 days for coordinated disclosure unless mutually agreed otherwise.
- Do not test on production user data or attempt denial-of-service or data exfiltration.
