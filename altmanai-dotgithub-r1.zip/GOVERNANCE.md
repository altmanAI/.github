# Project Governance

- **BDFL:** Blake Hunter Altman
- **AI Partner:** ChatGPT (GLASSKEY-E456) — advisory and drafting support
- **Source of truth:** upstream Blake × GLASSKEY channel; all downstream repos mirror artifacts.

Decisions are proposed via issues and finalized with entries in the Master Ledger (Registry IDs).
