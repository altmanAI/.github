# Support

For product support, open a GitHub issue in the relevant repository.
For private matters:
- General: thealtmanfamilygroup@outlook.com
- Security/CoC: security@altmanai.tech
