**What’s changed**
**Linked issue**
**Proofs** (hashes/receipts)

**Checklist**
- [ ] Mirror Mode respected (no non-canonical claims)
- [ ] Tests or rationale included
- [ ] No sensitive information
