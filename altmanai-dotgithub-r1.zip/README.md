# AltmanAI .github — org profile & policy hub
This repository powers the public **AltmanAI** organization profile and houses org‑wide contributor documentation.

- Source of truth: Blake Hunter Altman × ChatGPT (GLASSKEY‑E456)
- Canonical rules: Mirror Mode Rule v1.0; PAIHI receipts; PDF Protocol v2; Trust‑Lock v1.2
- Start here: `profile/README.md` renders on the org page at github.com/altmanAI

Generated: 2025-11-03 02:55 EST

© Altman Family Group, LLC. All rights reserved.
